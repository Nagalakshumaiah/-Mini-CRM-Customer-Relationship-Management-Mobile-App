// screens/CustomersScreen.js
import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ActivityIndicator,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { fetchCustomers } from "../store/customerSlice";
import { useDispatch, useSelector } from "react-redux";
import AsyncStorage from "@react-native-async-storage/async-storage";

const dummyCustomers = [
  {
    id: "1",
    name: "Sneha Jain",
    company: "Acme Corp",
    phone: "+91 12345 67890",
    email: "sneha.jain@example.com",
  },
  {
    id: "2",
    name: "Lakshya sharma",
    company: "Beta Industries",
    phone: "+91 98765 43210",
    email: "lakshya.sharma@example.com",
  },
  {
    id: "3",
    name: "Aarav Mehta",
    company: "Gamma Solutions",
    phone: "+91 54321 67890",
    email: "aarav.mehta@example.com",
  },
  {
    id: "4",
    name: "Diya Kapoor",
    company: "Delta Services",
    phone: "+91 67890 12345",
    email: "diya.kapoor@example.com",
  },

  {
    id: "5",
    name: "Rohan Verma",
    company: "Epsilon Tech",
    phone: "+91 11223 44556",
    email: "rohan.verma@example.com",
  },
  {
    id: "6",
    name: "Maya Singh",
    company: "Zeta Innovations",
    phone: "+91 99887 66554",
    email: "maya.singh@example.com",
  },
  // Add more dummy objects here...
];

export default function CustomersScreen() {
  const navigation = useNavigation<any>();
  const dispatch = useDispatch<any>();
  const { customers, loading, error } = useSelector(
    (state: any) => state.customers
  );

  const fetchToken = async () => {
    return await AsyncStorage.getItem("auth");
  };

  useEffect(() => {
    fetchToken().then((res: any) => {
      const token = res.token;
      dispatch(fetchCustomers({ token }));
    });
  }, [dispatch]);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#1661da" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={{ color: "red" }}>{error}</Text>
      </View>
    );
  }

  const [searchQuery, setSearchQuery] = useState("");
  const [filteredCustomers, setFilteredCustomers] = useState(dummyCustomers);

  useEffect(() => {
    // on searchQuery change, filter list
    const q = searchQuery.toLowerCase();
    const filtered = dummyCustomers.filter((c) => {
      return (
        c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)
      );
    });
    setFilteredCustomers(filtered);
  }, [searchQuery]);

  const renderItem = useCallback(({ item }: any) => {
    return (
      <TouchableOpacity
        style={styles.itemContainer}
        onPress={() => {
          navigation.navigate("CustomerDetails", { customerId: item.id });
        }}
      >
        <View
          style={[
            styles.avatar,
            {
              borderRadius: 50,
              backgroundColor: "#dbeafe",
              alignItems: "center",
              justifyContent: "center",
            },
          ]}
        >
          <Text style={{ fontSize: 24, color: "#1661da", fontWeight: "bold" }}>
            {item.name.charAt(0).toUpperCase()}
          </Text>
        </View>
        <View style={styles.itemInfo}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.itemSub}>
            {item.company} | {item.phone}
          </Text>
          <Text style={styles.itemSub}>{item.email}</Text>
        </View>
        <Ionicons name="chevron-forward" size={20} color="#94a3b8" />
      </TouchableOpacity>
    );
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Customers</Text>
      </View>

      {/* Search Bar */}
      <View style={styles.searchWrapper}>
        <Ionicons
          name="search"
          size={20}
          color="#94a3b8"
          style={styles.searchIcon}
        />
        <TextInput
          placeholder="Search by name or email"
          placeholderTextColor="#94a3b8"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      {/* List */}
      <FlatList
        data={filteredCustomers}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 100 }}
        // divide by separators
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      {/* Floating Add Button */}
      <TouchableOpacity
        style={styles.floatingAdd}
        onPress={() => navigation.navigate("AddCustomer")}
      >
        <Ionicons name="add" size={32} color="white" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f6f7f8" },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 12,
    backgroundColor: "#f6f7f8",
    borderBottomWidth: 1,
    borderColor: "#e5e7eb",
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#111827",
  },

  searchWrapper: {
    flexDirection: "row",
    alignItems: "center",
    margin: 12,
    backgroundColor: "#ffffff",
    borderRadius: 8,
    paddingHorizontal: 8,
  },
  searchIcon: {
    marginRight: 6,
  },
  searchInput: {
    flex: 1,
    height: 40,
    color: "#111827",
  },

  itemContainer: {
    flexDirection: "row",
    padding: 12,
    alignItems: "center",
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 12,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#111827",
  },
  itemSub: {
    fontSize: 13,
    color: "#6b7280",
  },
  separator: {
    height: 1,
    backgroundColor: "#e5e7eb",
    marginLeft: 12 + 56 + 12, // to align after avatar
  },

  pagination: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    padding: 12,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
  },
  pageBtn: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    marginHorizontal: 4,
    borderRadius: 6,
    backgroundColor: "#ffffff",
  },
  pageActive: {
    backgroundColor: "#1661da",
  },

  floatingAdd: {
    position: "absolute",
    bottom: 24,
    right: 24,
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "#1661da",
    alignItems: "center",
    justifyContent: "center",
    elevation: 6, // for Android shadow
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
});
