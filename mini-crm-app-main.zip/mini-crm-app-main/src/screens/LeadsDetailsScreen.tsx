import React, { useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from "react-native";
import { Picker } from "@react-native-picker/picker";
import Ionicons from "@expo/vector-icons/Ionicons";
import { SafeAreaView } from "react-native-safe-area-context";

export default function LeadDetailsScreen({ navigation }: any) {
  const [status, setStatus] = useState("New");

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Lead Details</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* Body */}
        <ScrollView style={styles.content}>
          <View style={{ marginBottom: 24 }}>
            <Text style={styles.title}>Potential Client</Text>
            <Text style={styles.description}>
              This lead represents a potential client interested in our
              services. They have shown interest in our premium package and
              require a follow-up.
            </Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Value</Text>
            <Text style={styles.value}>$5,000</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Created At</Text>
            <Text style={styles.value}>2023-11-15</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Status</Text>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>{status}</Text>
            </View>
          </View>

          {/* Update Status */}
          <View style={{ marginTop: 32 }}>
            <Text style={styles.inputLabel}>Update Status</Text>
            <View style={styles.pickerWrapper}>
              <Picker
                selectedValue={status}
                onValueChange={(v: any) => setStatus(v)}
                style={styles.picker}
              >
                <Picker.Item label="New" value="New" />
                <Picker.Item label="Contacted" value="Contacted" />
                <Picker.Item label="Converted" value="Converted" />
                <Picker.Item label="Lost" value="Lost" />
              </Picker>
            </View>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: "#f6f7f8" },
  container: { flex: 1, backgroundColor: "#f6f7f8" },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(22, 97, 218, 0.2)",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#000" },
  content: { padding: 16 },
  title: { fontSize: 20, fontWeight: "700", color: "#000" },
  description: { marginTop: 8, color: "#555", lineHeight: 20 },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(22, 97, 218, 0.2)",
  },
  label: { color: "#555" },
  value: { fontWeight: "600", color: "#000" },
  statusBadge: {
    backgroundColor: "rgba(22, 97, 218, 0.2)",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  statusText: { color: "#1661da", fontWeight: "600" },
  inputLabel: { fontSize: 14, fontWeight: "500", color: "#555" },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: "rgba(22, 97, 218, 0.2)",
    borderRadius: 8,
    marginTop: 8,
  },
  picker: { color: "#000" },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    paddingVertical: 8,
    borderTopWidth: 1,
    borderTopColor: "rgba(22, 97, 218, 0.2)",
    backgroundColor: "#f6f7f8",
  },
  navItem: { alignItems: "center" },
  navItemActive: { alignItems: "center" },
  navText: { fontSize: 12, color: "#666", marginTop: 4 },
});
