import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";

type LeadStatus = "New" | "Contacted" | "Converted" | "Lost";

type Lead = {
  title: string;
  status: LeadStatus;
  date: string;
  value: number;
};

const leadsData: Lead[] = [
  { title: "Design System for App", status: "New", date: "Oct 26, 2023", value: 1000 },
  { title: "New Website for Agency", status: "Contacted", date: "Oct 25, 2023", value: 2500 },
  { title: "Mobile App Redesign", status: "Converted", date: "Oct 24, 2023", value: 500 },
  { title: "Brand Identity for Startup", status: "New", date: "Oct 23, 2023", value: 1200 },
  { title: "CRM Integration Project", status: "Contacted", date: "Oct 22, 2023", value: 3000 },
  { title: "E-commerce Platform Dev", status: "Lost", date: "Oct 21, 2023", value: 800 },
];

// Status colors
const statusColors: Record<LeadStatus, { bg: string; text: string }> = {
  New: { bg: "#DBEAFE", text: "#1D4ED8" }, // blue
  Contacted: { bg: "#EDE9FE", text: "#7C3AED" }, // purple
  Converted: { bg: "#DCFCE7", text: "#15803D" }, // green
  Lost: { bg: "#FEE2E2", text: "#B91C1C" }, // red
};

export default function LeadsScreen() {
  const navigation = useNavigation<any>();

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Leads</Text>
        </View>

        {/* Tabs */}
        <View style={[styles.tabs, { flexDirection: "row", paddingHorizontal: 16, height: 40 }]}>
          {["All", "New", "Contacted", "Converted", "Lost"].map((tab, idx) => (
            <TouchableOpacity key={idx} style={tab === "All" ? styles.activeTab : styles.tab}>
              <Text style={tab === "All" ? styles.activeTabText : styles.tabText}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Leads List */}
        <ScrollView style={styles.leadsList}>
          {leadsData.map((lead, idx) => (
            <TouchableOpacity key={idx}onPress={() => navigation.navigate("LeadsDetails")}>
            <View key={idx} style={styles.leadItem}>
              <View style={{ flex: 1 }}>
                <Text style={styles.leadTitle}>{lead.title}</Text>
                <View style={styles.leadMeta}>
                  <View
                    style={[
                      styles.statusBadge,
                      { backgroundColor: statusColors[lead.status].bg },
                    ]}
                  >
                    <Text style={{ color: statusColors[lead.status].text, fontSize: 12 }}>
                      {lead.status}
                    </Text>
                  </View>
                  <Text style={styles.leadDate}>{lead.date}</Text>
                </View>
              </View>
              <Text style={styles.leadValue}>${lead.value}</Text>
            </View>
            </TouchableOpacity>
          ))}
          
        </ScrollView>

        {/* Add Lead Floating Button */}
        <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate("AddLeads")}>
          <Ionicons name="add" size={28} color="#fff" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#f6f7f8" },
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
    backgroundColor: "#f6f7f8",
  },
  headerTitle: { fontSize: 18, fontWeight: "700", color: "#0f172a" },
  tabs: {
    width: "100%",
    height: 40,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  tab: { paddingVertical: 10, paddingHorizontal: 16 },
  tabText: { fontSize: 14, fontWeight: "500", color: "#64748b" },
  activeTab: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderBottomWidth: 2,
    borderBottomColor: "#1661da",
  },
  activeTabText: { fontSize: 14, fontWeight: "600", color: "#1661da" },
  leadsList: { flex: 1 },
  leadItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  leadTitle: { fontSize: 16, fontWeight: "600", color: "#0f172a" },
  leadMeta: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 4 },
  statusBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  leadDate: { fontSize: 12, color: "#64748b" },
  leadValue: { fontSize: 16, fontWeight: "600", color: "#0f172a" },
  fab: {
    position: "absolute",
    right: 16,
    bottom: 24,
    backgroundColor: "#1661da",
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 4,
  },
});
