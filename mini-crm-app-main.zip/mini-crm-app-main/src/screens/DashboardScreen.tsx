import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import React from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { BarChart, PieChart } from "react-native-chart-kit";
import { SafeAreaView } from "react-native-safe-area-context";
import { useDispatch } from "react-redux";

const screenWidth = Dimensions.get("window").width;

export default function DashboardScreen() {
  const navigation = useNavigation();
  const dispatch = useDispatch<any>();
  const barData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May"],
    datasets: [
      {
        data: [50, 60, 80, 70, 30],
      },
    ],
  };

  const pieData = [
    {
      name: "Closed",
      population: 60,
      color: "#1661da",
      legendFontColor: "#0f172a",
      legendFontSize: 12,
    },
    {
      name: "Qualified",
      population: 30,
      color: "#facc15",
      legendFontColor: "#0f172a",
      legendFontSize: 12,
    },
    {
      name: "Open",
      population: 10,
      color: "#c7d2fe",
      legendFontColor: "#0f172a",
      legendFontSize: 12,
    },
  ];

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView style={styles.scroll}>
        <View style={{ flexDirection: "row",justifyContent: "space-between", alignItems: "center" }}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <TouchableOpacity
            onPress={() => {
              // Dispatch logout action
              dispatch({ type: "auth/logout" });
              navigation.navigate("Login" as never);
            }}
          >
            <Ionicons name="log-out" size={24} color="#0f172a" />
          </TouchableOpacity>
        </View>

        {/* Total Value of Leads */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Total Value of Leads</Text>
          <Text style={styles.cardValue}>$120,000</Text>
          <Text style={styles.cardMeta}>This Month +10%</Text>

          <BarChart
            data={barData}
            width={screenWidth - 40}
            height={200}
            fromZero
            yAxisLabel="$"
            yAxisSuffix=""
            chartConfig={{
              backgroundGradientFrom: "#f6f7f8",
              backgroundGradientTo: "#f6f7f8",
              color: (opacity = 1) => `rgba(22,97,218,${opacity})`,
              barPercentage: 0.5,
            }}
            style={{ marginTop: 16, borderRadius: 16 }}
          />
        </View>

        {/* Leads by Status */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Leads by Status</Text>
          <Text style={styles.cardValue}>15</Text>
          <Text style={styles.cardMeta}>This Month +5%</Text>

          <PieChart
            data={pieData}
            width={screenWidth - 40}
            height={200}
            accessor="population"
            backgroundColor="transparent"
            paddingLeft="15"
            absolute
            chartConfig={{
              color: (opacity = 1) => `rgba(22,97,218,${opacity})`,
            }}
          />
        </View>

        <Text style={styles.sectionTitle}>Summary</Text>
        <View style={styles.cardsRow}>
          <View style={styles.summaryCard}>
            <Text style={styles.cardLabel}>Total Customers</Text>
            <Text style={styles.cardValue}>50</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={styles.cardLabel}>Total Leads</Text>
            <Text style={styles.cardValue}>20</Text>
          </View>
          <View style={styles.summaryCard}>
            <Text style={styles.cardLabel}>Total Value</Text>
            <Text style={styles.cardValue}>$150,000</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  scroll: { flex: 1, paddingHorizontal: 16 },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "700",
    marginVertical: 12,
    color: "#0f172a",
  },
  card: {
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    marginBottom: 16,
  },
  cardLabel: { fontSize: 14, color: "#6b7280" },
  cardValue: {
    fontSize: 28,
    fontWeight: "700",
    marginTop: 4,
    color: "#0f172a",
  },
  cardMeta: { fontSize: 12, color: "#6b7280", marginTop: 4 },
  cardsRow: { flex: 1, flexWrap: "wrap", gap: 12, marginBottom: 12 },
  summaryCard: {
    flex: 1,
    width: "100%",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    marginBottom: 12,
  },
});
