import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";

export default function CustomerDetailsScreen() {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color="#0e131b" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Customer Details</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Content */}
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.profileContainer}>
          <View style={styles.avatarWrapper}>
            <View
              style={[
                styles.avatar,
                {
                  borderRadius: 100,
                  backgroundColor: "#dbeafe",
                  alignItems: "center",
                  justifyContent: "center",
                },
              ]}
            >
              <Text
                style={{ fontSize: 36, color: "#1661da", fontWeight: "bold" }}
              >
                E
              </Text>
            </View>
            <View style={styles.avatarBadge}>
              <MaterialIcons name="person" size={16} color="#1661da" />
            </View>
          </View>
          <Text style={styles.name}>Ethan Carter</Text>
          <Text style={styles.email}>ethan.carter@example.com</Text>
          <Text style={styles.email}>+1 (555) 123-4567</Text>
        </View>

        {/* Company */}
        <View style={styles.card}>
          <Text style={styles.cardLabel}>Company</Text>
          <Text style={styles.cardValue}>Tech Solutions Inc.</Text>
        </View>

        {/* Associated Leads */}
        <Text style={styles.sectionTitle}>Associated Leads</Text>

        <View style={styles.list}>
          {[
            { id: 1, title: "Lead 1", subtitle: "Product Demo" },
            { id: 2, title: "Lead 2", subtitle: "Follow-up Meeting" },
          ].map((lead) => (
            <TouchableOpacity key={lead.id} style={styles.listItem}>
              <View style={styles.iconWrapper}>
                <MaterialIcons name="description" size={24} color="#1661da" />
              </View>
              <View style={styles.listText}>
                <Text style={styles.listTitle}>{lead.title}</Text>
                <Text style={styles.listSubtitle}>{lead.subtitle}</Text>
              </View>
              <MaterialIcons name="chevron-right" size={24} color="#6b7280" />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.editButton}>
          <Text style={styles.editText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.deleteButton}>
          <Text style={styles.deleteText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f6f7f8",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    height: 56,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    backgroundColor: "#f6f7f8",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#0e131b",
  },
  content: {
    padding: 16,
  },
  profileContainer: {
    alignItems: "center",
    marginBottom: 24,
  },
  avatarWrapper: {
    position: "relative",
    marginBottom: 12,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  avatarBadge: {
    position: "absolute",
    bottom: 4,
    right: 4,
    backgroundColor: "rgba(22,97,218,0.1)",
    padding: 4,
    borderRadius: 999,
  },
  name: {
    fontSize: 22,
    fontWeight: "700",
    color: "#0e131b",
  },
  email: {
    fontSize: 14,
    color: "#6b7280",
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  cardLabel: {
    fontSize: 13,
    color: "#6b7280",
    marginBottom: 4,
  },
  cardValue: {
    fontSize: 16,
    fontWeight: "500",
    color: "#0e131b",
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 8,
    color: "#0e131b",
  },
  list: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
  },
  listItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  iconWrapper: {
    backgroundColor: "rgba(22,97,218,0.1)",
    padding: 8,
    borderRadius: 999,
    marginRight: 12,
  },
  listText: {
    flex: 1,
  },
  listTitle: {
    fontWeight: "600",
    fontSize: 16,
    color: "#0e131b",
  },
  listSubtitle: {
    fontSize: 13,
    color: "#6b7280",
  },
  footer: {
    flexDirection: "row",
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
    backgroundColor: "#f6f7f8",
    gap: 12,
  },
  editButton: {
    flex: 1,
    backgroundColor: "rgba(22,97,218,0.1)",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    height: 48,
  },
  editText: {
    color: "#1661da",
    fontWeight: "700",
  },
  deleteButton: {
    flex: 1,
    backgroundColor: "#1661da",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    height: 48,
  },
  deleteText: {
    color: "#ffffff",
    fontWeight: "700",
  },
});
