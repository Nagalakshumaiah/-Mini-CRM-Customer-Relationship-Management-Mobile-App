// RegisterScreen.js
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from "react-native";
import { TextInput, Button } from "react-native-paper";
import { LinearGradient } from "expo-linear-gradient";
import { useDispatch, useSelector } from "react-redux";
import { registerUser } from "../store/authSlice";
import axios from "axios";
import { API_URL } from "../utils/constant";

export default function RegisterScreen({ navigation }: any) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const dispatch = useDispatch<any>();
  const [loading, setLoading] = useState(false);


  const handleSignUp = async () => {
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/auth/register`, {
        name: fullName,
        email,
        password,
      });
      const res = response.data; // assume API returns { user, token }
      Alert.alert("Success", "User registered successfully!", [
        { text: "OK", onPress: () => navigation.navigate("Login") },
      ]);
    } catch (error) {
      console.error(error);
      setError(error.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={["#1661da", "#166199"]} style={{ flex: 1 }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.container}
      >
        <ScrollView
          style={styles.container}
          contentContainerStyle={styles.scrollContainer}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            <View style={styles.headerContainer}>
              <Text style={styles.title}>Create Account</Text>
              <Text style={styles.subtitle}>
                Let's get started with your 30 day free trial.
              </Text>
            </View>

            <View style={styles.inputContainer}>
              <TextInput
                label="Full Name"
                value={fullName}
                onChangeText={setFullName}
                mode="outlined"
                style={styles.input}
                placeholder="Full Name"
                theme={inputTheme}
              />

              <TextInput
                label="Email"
                value={email}
                onChangeText={setEmail}
                mode="outlined"
                style={styles.input}
                placeholder="you@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                theme={inputTheme}
              />

              <TextInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                mode="outlined"
                secureTextEntry
                style={styles.input}
                placeholder="••••••••"
                theme={inputTheme}
              />

              <TextInput
                label="Confirm Password"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                mode="outlined"
                secureTextEntry
                style={styles.input}
                placeholder="••••••••"
                theme={inputTheme}
              />

              {error ? <Text style={styles.errorText}>{error}</Text> : null}

              <Button
                mode="contained"
                onPress={handleSignUp}
                style={styles.signUpButton}
                labelStyle={{ fontWeight: "bold", fontSize: 16 }}
              >
                {loading ? "Signing Up..." : "Sign Up"}
              </Button>
            </View>

            <Text style={styles.footerText}>
              Already have an account?{" "}
              <Text
                style={styles.link}
                onPress={() => navigation.navigate("Login")}
              >
                Log In
              </Text>
            </Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const inputTheme = {
  colors: {
    primary: "#3B82F6",
    background: "#FFFFFF",
  },
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 24,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 20,
  },
  backButton: {
    marginBottom: 20,
    alignSelf: "flex-start",
  },
  backArrow: {
    fontSize: 28,
    color: "#1F2937",
  },
  headerContainer: {
    marginBottom: 20,
  },
  title: {
    fontSize: 30,
    fontWeight: "700",
    textAlign: "center",
    color: "#1F2937",
  },
  subtitle: {
    textAlign: "center",
    color: "#6b7280",
    marginTop: 8,
  },
  inputContainer: {
    marginTop: 16,
  },
  input: {
    marginBottom: 12,
    backgroundColor: "#FFFFFF",
  },
  signUpButton: {
    backgroundColor: "#3B82F6",
    paddingVertical: 8,
    borderRadius: 8,
    marginTop: 12,
  },
  errorText: {
    color: "#ef4444",
    marginBottom: 8,
    textAlign: "center",
    fontSize: 13,
  },
  footerText: {
    textAlign: "center",
    marginTop: 24,
    color: "#6b7280",
  },
  link: {
    color: "#3B82F6",
    fontWeight: "600",
  },
});
