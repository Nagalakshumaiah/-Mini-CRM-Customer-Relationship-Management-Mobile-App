import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import { API_URL } from "../utils/constant";

// Async thunk to fetch customers
export const fetchCustomers = createAsyncThunk(
  "customers/fetchCustomers",
  async (tokens:any, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_URL}/customers`, {
        headers: {
          Authorization: tokens.token ? `Bearer ${tokens}` : "",
        }
      });
      console.log("Fetched customers:", response.data);
      return response.data; // assuming API returns an array of customers
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

const customersSlice = createSlice({
  name: "customers",
  initialState: {
    customers: [],
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCustomers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCustomers.fulfilled, (state, action) => {
        state.loading = false;
        state.customers = action.payload;
      })
      .addCase(fetchCustomers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "Failed to fetch customers";
      });
  },
});

export default customersSlice.reducer;
