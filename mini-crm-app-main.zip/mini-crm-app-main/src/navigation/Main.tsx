import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Provider as PaperProvider } from "react-native-paper";

import LoginScreen from "../screens/LoginScreen";
import RegisterScreen from "../screens/RegisterScreen";
import BottomTabs from "./BottomTabs";
import AddCustomerScreen from "../screens/AddCustomerScreen";
import CustomerDetailsScreen from "../screens/CustomerDetails";
import NewLeadScreen from "../screens/AddLeadsScreen";
import LeadDetailsScreen from "../screens/LeadsDetailsScreen";
import { useSelector } from "react-redux";

const Stack = createNativeStackNavigator();

export default function Main() {

    const {isAuthenticated} = useSelector((state:any)=> state.auth)


  return (
    <PaperProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName={isAuthenticated?"Home":"Login"}>
          <Stack.Screen
            name="Login"
            component={LoginScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Register"
            component={RegisterScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Home"
            component={BottomTabs}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="AddCustomer"
            component={AddCustomerScreen}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="CustomerDetails"
            component={CustomerDetailsScreen}
            options={{ headerShown: false }}
          />

          <Stack.Screen
            name="AddLeads"
            component={NewLeadScreen}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="LeadsDetails"
            component={LeadDetailsScreen}
            options={{ headerShown: false }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}
